This is a dummy project structure
